import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CheckCircle, AlertCircle, Loader2 } from "lucide-react";

export default function OrderConfirmation() {
  const [, navigate] = useLocation();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [orderDetails, setOrderDetails] = useState<any>(null);
  const [sessionId, setSessionId] = useState("");

  useEffect(() => {
    // Get session ID from URL
    const params = new URLSearchParams(window.location.search);
    const sid = params.get("session_id");

    if (sid) {
      setSessionId(sid);
      // Fetch session details from backend
      fetchSessionDetails(sid);
    } else {
      setStatus("error");
    }
  }, []);

  const fetchSessionDetails = async (sessionId: string) => {
    try {
      // This would call the payment.getCheckoutSession procedure
      // For now, we'll simulate success
      await new Promise((resolve) => setTimeout(resolve, 2000));

      setOrderDetails({
        orderNumber: "ORD-" + Date.now(),
        customerEmail: "customer@example.com",
        totalAmount: 249,
        status: "processing",
      });
      setStatus("success");
    } catch (error) {
      console.error("Failed to fetch order details:", error);
      setStatus("error");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white py-12">
      <div className="container max-w-2xl">
        {status === "loading" && (
          <Card className="p-12 text-center">
            <Loader2 className="w-12 h-12 text-teal-500 mx-auto mb-4 animate-spin" />
            <p className="text-lg text-gray-600">Processing your order...</p>
          </Card>
        )}

        {status === "success" && orderDetails && (
          <div className="space-y-6">
            {/* Success Message */}
            <Card className="p-8 bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
              <div className="flex items-center gap-4 mb-6">
                <CheckCircle className="w-12 h-12 text-green-600" />
                <div>
                  <h1 className="text-3xl font-bold text-gray-900">Order Confirmed!</h1>
                  <p className="text-gray-600">
                    Thank you for your purchase. Your custom pet portrait is on its way.
                  </p>
                </div>
              </div>
            </Card>

            {/* Order Details */}
            <Card className="p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Order Details</h2>
              <div className="space-y-4">
                <div className="flex justify-between border-b border-gray-200 pb-4">
                  <span className="text-gray-600">Order Number</span>
                  <span className="font-semibold text-gray-900">{orderDetails.orderNumber}</span>
                </div>
                <div className="flex justify-between border-b border-gray-200 pb-4">
                  <span className="text-gray-600">Email</span>
                  <span className="font-semibold text-gray-900">{orderDetails.customerEmail}</span>
                </div>
                <div className="flex justify-between border-b border-gray-200 pb-4">
                  <span className="text-gray-600">Order Total</span>
                  <span className="font-semibold text-gray-900">
                    ${(orderDetails.totalAmount / 100).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Status</span>
                  <span className="inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                    {orderDetails.status}
                  </span>
                </div>
              </div>
            </Card>

            {/* What's Next */}
            <Card className="p-8 bg-gradient-to-br from-teal-50 to-cyan-50 border-teal-200">
              <h3 className="text-xl font-bold text-gray-900 mb-4">What's Next?</h3>
              <div className="space-y-3">
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-teal-500 text-white flex items-center justify-center flex-shrink-0 text-sm font-bold">
                    1
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Confirmation Email</p>
                    <p className="text-sm text-gray-600">
                      Check your email for order confirmation and details.
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-teal-500 text-white flex items-center justify-center flex-shrink-0 text-sm font-bold">
                    2
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">AI Preview Generation</p>
                    <p className="text-sm text-gray-600">
                      We'll generate a preview of your portrait within 24 hours.
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-teal-500 text-white flex items-center justify-center flex-shrink-0 text-sm font-bold">
                    3
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Artist Creation</p>
                    <p className="text-sm text-gray-600">
                      Our artists will create your custom portrait over the next 5-7 days.
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="w-6 h-6 rounded-full bg-teal-500 text-white flex items-center justify-center flex-shrink-0 text-sm font-bold">
                    4
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Shipping</p>
                    <p className="text-sm text-gray-600">
                      Your framed portrait will be shipped within 2-3 business days.
                    </p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Preview Section */}
            <Card className="p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-4">Your Portrait Preview</h3>
              <div className="bg-gradient-to-br from-purple-100 to-pink-100 rounded-lg h-64 flex items-center justify-center text-gray-600">
                <div className="text-center">
                  <p className="text-lg font-semibold mb-2">Preview Coming Soon</p>
                  <p className="text-sm">
                    Your AI-generated preview will appear here within 24 hours
                  </p>
                </div>
              </div>
            </Card>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => navigate("/")}
                variant="outline"
                className="flex-1"
              >
                Back to Home
              </Button>
              <Button
                onClick={() => navigate("/")}
                className="flex-1 bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white"
              >
                Create Another Portrait
              </Button>
            </div>
          </div>
        )}

        {status === "error" && (
          <Card className="p-8 bg-gradient-to-br from-red-50 to-orange-50 border-red-200">
            <div className="flex items-center gap-4 mb-6">
              <AlertCircle className="w-12 h-12 text-red-600" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Something Went Wrong</h1>
                <p className="text-gray-600">
                  We couldn't process your order. Please try again or contact support.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <Button
                onClick={() => navigate("/")}
                variant="outline"
              >
                Go Home
              </Button>
              <Button
                onClick={() => navigate("/order")}
                className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white"
              >
                Try Again
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
