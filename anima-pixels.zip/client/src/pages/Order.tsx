import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useLocation } from "wouter";
import { ChevronLeft, Upload, Check } from "lucide-react";

type OrderStep = "photo" | "customize" | "customer" | "summary" | "payment";

const SIZES = ["8×10", "12×12", "12×16", "18×24"];
const FRAMES = [
  { name: "Wood Frame", color: "from-amber-700 to-amber-600" },
  { name: "Black Frame", color: "from-gray-800 to-gray-700" },
  { name: "White Frame", color: "from-gray-100 to-gray-50" },
];
const ART_STYLES = [
  { name: "Watercolor", icon: "🎨" },
  { name: "Oil Painting", icon: "🖼️" },
  { name: "Digital Art", icon: "✨" },
  { name: "Sketch", icon: "✏️" },
  { name: "Royal Classic", icon: "👑" },
  { name: "Cartoon Fun", icon: "😄" },
];

const PRICING = {
  "8×10": 199,
  "12×12": 249,
  "12×16": 299,
  "18×24": 399,
};

export default function Order() {
  const [, navigate] = useLocation();
  const [currentStep, setCurrentStep] = useState<OrderStep>("photo");
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>("");
  const [selectedStyle, setSelectedStyle] = useState("Watercolor");
  const [selectedFrame, setSelectedFrame] = useState("Wood Frame");
  const [selectedSize, setSelectedSize] = useState("12×12");
  const [petName, setPetName] = useState("");
  const [petDescription, setPetDescription] = useState("");
  const [specialInstructions, setSpecialInstructions] = useState("");
  const [customerInfo, setCustomerInfo] = useState({
    fullName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    country: "",
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onload = (event) => {
        setPhotoPreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCustomerChange = (field: string, value: string) => {
    setCustomerInfo((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const totalPrice = PRICING[selectedSize as keyof typeof PRICING] || 249;

  const steps = [
    { id: "photo", label: "Photo", number: 1 },
    { id: "customize", label: "Customize", number: 2 },
    { id: "customer", label: "Info", number: 3 },
    { id: "summary", label: "Review", number: 4 },
    { id: "payment", label: "Payment", number: 5 },
  ];

  const getStepIndex = (step: OrderStep) => steps.findIndex((s) => s.id === step);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white py-8">
      <div className="container max-w-4xl">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/")}
            className="hover:bg-gray-200"
          >
            <ChevronLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Create Your Portrait</h1>
        </div>

        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex justify-between mb-4">
            {steps.map((step, idx) => (
              <div key={step.id} className="flex flex-col items-center flex-1">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold mb-2 transition-all ${
                    getStepIndex(currentStep) >= idx
                      ? "bg-gradient-to-r from-teal-500 to-cyan-500 text-white"
                      : "bg-gray-200 text-gray-600"
                  }`}
                >
                  {getStepIndex(currentStep) > idx ? (
                    <Check className="w-5 h-5" />
                  ) : (
                    step.number
                  )}
                </div>
                <span className="text-xs md:text-sm text-gray-600 text-center">{step.label}</span>
              </div>
            ))}
          </div>
          <div className="h-1 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-teal-500 to-cyan-500 transition-all duration-300"
              style={{ width: `${((getStepIndex(currentStep) + 1) / steps.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Step 1: Photo Upload */}
        {currentStep === "photo" && (
          <Card className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Upload Your Pet's Photo</h2>
            <div className="space-y-6">
              <div
                className="border-2 border-dashed border-teal-300 rounded-lg p-12 text-center cursor-pointer hover:bg-teal-50 transition"
                onClick={() => fileInputRef.current?.click()}
              >
                {photoPreview ? (
                  <div className="space-y-4">
                    <img
                      src={photoPreview}
                      alt="Preview"
                      className="max-h-64 mx-auto rounded-lg"
                    />
                    <p className="text-sm text-gray-600">Click to change photo</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <Upload className="w-12 h-12 text-teal-500 mx-auto" />
                    <div>
                      <p className="text-lg font-semibold text-gray-900">
                        Drag and drop your photo here
                      </p>
                      <p className="text-sm text-gray-600">or click to browse</p>
                    </div>
                  </div>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
              <p className="text-sm text-gray-600">
                Supported formats: JPG, PNG, GIF (Max 10MB). For best results, use a clear,
                well-lit photo of your pet.
              </p>
            </div>
            <div className="flex justify-end gap-4 mt-8">
              <Button
                onClick={() => setCurrentStep("customize")}
                disabled={!photoFile}
                className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white"
              >
                Next: Customize
              </Button>
            </div>
          </Card>
        )}

        {/* Step 2: Customize */}
        {currentStep === "customize" && (
          <Card className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Customize Your Portrait</h2>
            <div className="space-y-8">
              {/* Pet Name & Description */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">Pet Information</h3>
                <Input
                  placeholder="Pet's name"
                  value={petName}
                  onChange={(e) => setPetName(e.target.value)}
                  className="border-gray-300"
                />
                <Textarea
                  placeholder="Describe how you want your pet to look. Include outfit, mood, theme, personality..."
                  value={petDescription}
                  onChange={(e) => setPetDescription(e.target.value)}
                  className="border-gray-300 min-h-24"
                />
              </div>

              {/* Art Style */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">Choose Portrait Style</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {ART_STYLES.map((style) => (
                    <button
                      key={style.name}
                      onClick={() => setSelectedStyle(style.name)}
                      className={`p-4 rounded-lg border-2 transition ${
                        selectedStyle === style.name
                          ? "border-teal-500 bg-teal-50"
                          : "border-gray-200 hover:border-teal-300"
                      }`}
                    >
                      <div className="text-3xl mb-2">{style.icon}</div>
                      <p className="text-sm font-medium text-gray-900">{style.name}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Frame Selection */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">Choose Frame</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {FRAMES.map((frame) => (
                    <button
                      key={frame.name}
                      onClick={() => setSelectedFrame(frame.name)}
                      className={`p-4 rounded-lg border-2 transition ${
                        selectedFrame === frame.name
                          ? "border-teal-500 bg-teal-50"
                          : "border-gray-200 hover:border-teal-300"
                      }`}
                    >
                      <div
                        className={`h-32 bg-gradient-to-br ${frame.color} rounded mb-3 border-8 border-gray-300`}
                      ></div>
                      <p className="text-sm font-medium text-gray-900">{frame.name}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Size Selection */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">Select Size</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {SIZES.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`p-4 rounded-lg border-2 text-center transition ${
                        selectedSize === size
                          ? "border-teal-500 bg-teal-50"
                          : "border-gray-200 hover:border-teal-300"
                      }`}
                    >
                      <p className="font-semibold text-gray-900">{size}</p>
                      <p className="text-sm text-gray-600">
                        ${PRICING[size as keyof typeof PRICING]}
                      </p>
                    </button>
                  ))}
                </div>
                <p className="text-sm text-gray-600">
                  Need a custom size? Tell us—we love special requests.
                </p>
              </div>

              {/* Special Instructions */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-gray-900">Special Instructions</h3>
                <Textarea
                  placeholder="Any additional details or special requests..."
                  value={specialInstructions}
                  onChange={(e) => setSpecialInstructions(e.target.value)}
                  className="border-gray-300 min-h-20"
                />
              </div>
            </div>
            <div className="flex justify-between gap-4 mt-8">
              <Button variant="outline" onClick={() => setCurrentStep("photo")}>
                Back
              </Button>
              <Button
                onClick={() => setCurrentStep("customer")}
                className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white"
              >
                Next: Your Information
              </Button>
            </div>
          </Card>
        )}

        {/* Step 3: Customer Information */}
        {currentStep === "customer" && (
          <Card className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Information</h2>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  placeholder="Full Name"
                  value={customerInfo.fullName}
                  onChange={(e) => handleCustomerChange("fullName", e.target.value)}
                  className="border-gray-300"
                />
                <Input
                  placeholder="Email Address"
                  type="email"
                  value={customerInfo.email}
                  onChange={(e) => handleCustomerChange("email", e.target.value)}
                  className="border-gray-300"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input
                  placeholder="Phone Number"
                  value={customerInfo.phone}
                  onChange={(e) => handleCustomerChange("phone", e.target.value)}
                  className="border-gray-300"
                />
                <Input
                  placeholder="Country"
                  value={customerInfo.country}
                  onChange={(e) => handleCustomerChange("country", e.target.value)}
                  className="border-gray-300"
                />
              </div>
              <Input
                placeholder="Street Address"
                value={customerInfo.address}
                onChange={(e) => handleCustomerChange("address", e.target.value)}
                className="border-gray-300"
              />
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input
                  placeholder="City"
                  value={customerInfo.city}
                  onChange={(e) => handleCustomerChange("city", e.target.value)}
                  className="border-gray-300"
                />
                <Input
                  placeholder="State/Province"
                  value={customerInfo.state}
                  onChange={(e) => handleCustomerChange("state", e.target.value)}
                  className="border-gray-300"
                />
                <Input
                  placeholder="ZIP/Postal Code"
                  value={customerInfo.zipCode}
                  onChange={(e) => handleCustomerChange("zipCode", e.target.value)}
                  className="border-gray-300"
                />
              </div>
            </div>
            <div className="flex justify-between gap-4 mt-8">
              <Button variant="outline" onClick={() => setCurrentStep("customize")}>
                Back
              </Button>
              <Button
                onClick={() => setCurrentStep("summary")}
                className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white"
              >
                Review Order
              </Button>
            </div>
          </Card>
        )}

        {/* Step 4: Order Summary */}
        {currentStep === "summary" && (
          <Card className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Order Summary</h2>
            <div className="space-y-6">
              {/* Photo Preview */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Your Photo</h3>
                {photoPreview && (
                  <img src={photoPreview} alt="Preview" className="max-h-48 rounded-lg" />
                )}
              </div>

              {/* Customization Summary */}
              <div className="bg-gray-50 rounded-lg p-6 space-y-4">
                <h3 className="font-semibold text-gray-900">Customization Details</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Pet Name</p>
                    <p className="font-medium text-gray-900">{petName || "Not specified"}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Art Style</p>
                    <p className="font-medium text-gray-900">{selectedStyle}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Frame</p>
                    <p className="font-medium text-gray-900">{selectedFrame}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Size</p>
                    <p className="font-medium text-gray-900">{selectedSize}</p>
                  </div>
                </div>
                {petDescription && (
                  <div>
                    <p className="text-sm text-gray-600">Pet Description</p>
                    <p className="text-gray-700">{petDescription}</p>
                  </div>
                )}
              </div>

              {/* Customer Info Summary */}
              <div className="bg-gray-50 rounded-lg p-6 space-y-4">
                <h3 className="font-semibold text-gray-900">Shipping Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Name</p>
                    <p className="font-medium text-gray-900">{customerInfo.fullName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Email</p>
                    <p className="font-medium text-gray-900">{customerInfo.email}</p>
                  </div>
                  <div className="col-span-2">
                    <p className="text-sm text-gray-600">Address</p>
                    <p className="font-medium text-gray-900">
                      {customerInfo.address}, {customerInfo.city}, {customerInfo.state}{" "}
                      {customerInfo.zipCode}
                    </p>
                  </div>
                </div>
              </div>

              {/* Pricing Summary */}
              <div className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-lg p-6 space-y-3 border border-teal-200">
                <div className="flex justify-between">
                  <span className="text-gray-700">Portrait ({selectedSize})</span>
                  <span className="font-semibold text-gray-900">${totalPrice}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-700">Framing & Shipping</span>
                  <span className="font-semibold text-gray-900">Included</span>
                </div>
                <div className="border-t border-teal-200 pt-3 flex justify-between">
                  <span className="text-lg font-bold text-gray-900">Total</span>
                  <span className="text-lg font-bold text-teal-600">${totalPrice}</span>
                </div>
              </div>
            </div>
            <div className="flex justify-between gap-4 mt-8">
              <Button variant="outline" onClick={() => setCurrentStep("customer")}>
                Back
              </Button>
              <Button
                onClick={() => setCurrentStep("payment")}
                className="bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white"
              >
                Proceed to Payment
              </Button>
            </div>
          </Card>
        )}

        {/* Step 5: Payment */}
        {currentStep === "payment" && (
          <Card className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Secure Checkout</h2>
            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  ✓ Secure payment processing with Stripe
                </p>
              </div>

              {/* Stripe placeholder */}
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <p className="text-gray-600 mb-4">
                  Stripe payment form will be integrated here
                </p>
                <div className="space-y-3 text-left max-w-sm mx-auto">
                  <div className="bg-gray-100 h-12 rounded flex items-center px-4">
                    <span className="text-gray-500 text-sm">Card number</span>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="bg-gray-100 h-12 rounded flex items-center px-4">
                      <span className="text-gray-500 text-sm">MM/YY</span>
                    </div>
                    <div className="bg-gray-100 h-12 rounded flex items-center px-4">
                      <span className="text-gray-500 text-sm">CVC</span>
                    </div>
                    <div className="bg-gray-100 h-12 rounded flex items-center px-4">
                      <span className="text-gray-500 text-sm">ZIP</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Order Total */}
              <div className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-lg p-6 border border-teal-200">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold text-gray-900">Order Total</span>
                  <span className="text-3xl font-bold text-teal-600">${totalPrice}</span>
                </div>
              </div>

              <p className="text-xs text-gray-600">
                By clicking "Complete Purchase", you agree to our Terms of Service and Privacy
                Policy.
              </p>
            </div>
            <div className="flex justify-between gap-4 mt-8">
              <Button variant="outline" onClick={() => setCurrentStep("summary")}>
                Back
              </Button>
              <Button className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-8">
                Complete Purchase
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
