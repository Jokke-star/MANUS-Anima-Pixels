import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { createOrder, getOrderByNumber, getPortraitCustomization, updatePortraitPreview } from "./orders";
import { storagePut } from "./storage";
import { notifyOwner } from "./_core/notification";
import { generateImage } from "./_core/imageGeneration";

const orderInputSchema = z.object({
  email: z.string().email(),
  fullName: z.string().min(1),
  phone: z.string().optional(),
  address: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
  zipCode: z.string().optional(),
  country: z.string().optional(),
  petName: z.string().optional(),
  petDescription: z.string().optional(),
  artStyle: z.string().min(1),
  frameType: z.string().min(1),
  size: z.string().min(1),
  totalPrice: z.number().positive(),
  specialInstructions: z.string().optional(),
  photoBase64: z.string().optional(),
});

export const orderRouter = router({
  // Upload photo to S3
  uploadPhoto: publicProcedure
    .input(
      z.object({
        photoBase64: z.string(),
        fileName: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const buffer = Buffer.from(input.photoBase64, "base64");
        const fileKey = `portraits/${Date.now()}-${input.fileName}`;
        const { url } = await storagePut(fileKey, buffer, "image/jpeg");
        return { success: true, url };
      } catch (error) {
        console.error("[Order] Photo upload failed:", error);
        throw error;
      }
    }),

  // Create order
  createOrder: publicProcedure.input(orderInputSchema).mutation(async ({ input }) => {
    try {
      const orderData = {
        email: input.email,
        fullName: input.fullName,
        phone: input.phone,
        address: input.address,
        city: input.city,
        state: input.state,
        zipCode: input.zipCode,
        country: input.country,
        petName: input.petName,
        petDescription: input.petDescription,
        artStyle: input.artStyle,
        frameType: input.frameType,
        size: input.size,
        totalPrice: input.totalPrice,
        specialInstructions: input.specialInstructions,
      };

      const order = await createOrder(orderData);

      // Notify owner of new order
      await notifyOwner({
        title: "New Pet Portrait Order",
        content: `New order #${order.orderNumber} from ${input.fullName}. Pet: ${input.petName || "Not specified"}. Total: $${(input.totalPrice / 100).toFixed(2)}`,
      });

      return {
        success: true,
        orderId: order.orderId,
        orderNumber: order.orderNumber,
      };
    } catch (error) {
      console.error("[Order] Creation failed:", error);
      throw error;
    }
  }),

  // Get order details
  getOrder: publicProcedure
    .input(z.object({ orderNumber: z.string() }))
    .query(async ({ input }) => {
      try {
        const order = await getOrderByNumber(input.orderNumber);
        if (!order) {
          throw new Error("Order not found");
        }
        return order;
      } catch (error) {
        console.error("[Order] Fetch failed:", error);
        throw error;
      }
    }),

  // Generate AI preview
  generatePreview: publicProcedure
    .input(
      z.object({
        orderId: z.number(),
        photoUrl: z.string(),
        artStyle: z.string(),
        petDescription: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const descriptionText = input.petDescription ? `Details: ${input.petDescription}` : "Make it artistic and beautiful.";
        const prompt = `Create a ${input.artStyle} portrait of a pet. ${descriptionText}`;

        const result = await generateImage({
          prompt,
          originalImages: [
            {
              url: input.photoUrl,
              mimeType: "image/jpeg",
            },
          ],
        });

        // Save preview URL to database
        const previewUrl = result.url || "";
        if (previewUrl) {
          await updatePortraitPreview(input.orderId, previewUrl);
        }

        return {
          success: true,
          previewUrl,
        };
      } catch (error) {
        console.error("[Order] Preview generation failed:", error);
        throw error;
      }
    }),

  // Get portrait customization
  getPortraitCustomization: publicProcedure
    .input(z.object({ orderId: z.number() }))
    .query(async ({ input }) => {
      try {
        const customization = await getPortraitCustomization(input.orderId);
        return customization;
      } catch (error) {
        console.error("[Order] Fetch customization failed:", error);
        throw error;
      }
    }),
});
