import { eq } from "drizzle-orm";
import { customers, orders, portraitCustomizations } from "../drizzle/schema";
import { getDb } from "./db";
import { nanoid } from "nanoid";

export async function createOrder(data: {
  email: string;
  fullName: string;
  phone?: string;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
  petName?: string;
  petDescription?: string;
  artStyle: string;
  frameType: string;
  size: string;
  totalPrice: number;
  specialInstructions?: string;
  photoUrl?: string;
}) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    // Create or get customer
    const existingCustomer = await db
      .select()
      .from(customers)
      .where(eq(customers.email, data.email))
      .limit(1);

    let customerId: number;

    if (existingCustomer.length > 0) {
      customerId = existingCustomer[0].id;
    } else {
      const result = await db.insert(customers).values({
        email: data.email,
        fullName: data.fullName,
        phone: data.phone,
        address: data.address,
        city: data.city,
        state: data.state,
        zipCode: data.zipCode,
        country: data.country,
      });
      customerId = result[0].insertId as number;
    }

    // Create order
    const orderNumber = `ORD-${Date.now()}-${nanoid(6)}`;
    const orderResult = await db.insert(orders).values({
      customerId,
      orderNumber,
      status: "pending",
      totalPrice: data.totalPrice,
      specialInstructions: data.specialInstructions,
    });

    const orderId = orderResult[0].insertId as number;

    // Create portrait customization
    await db.insert(portraitCustomizations).values({
      orderId,
      petName: data.petName,
      petDescription: data.petDescription,
      artStyle: data.artStyle,
      frameType: data.frameType,
      size: data.size,
      photoUrl: data.photoUrl,
    });

    return {
      orderId,
      orderNumber,
      customerId,
      totalPrice: data.totalPrice,
    };
  } catch (error) {
    console.error("[Orders] Failed to create order:", error);
    throw error;
  }
}

export async function getOrderByNumber(orderNumber: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db
    .select()
    .from(orders)
    .where(eq(orders.orderNumber, orderNumber))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function getOrderById(orderId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function updateOrderStatus(orderId: number, status: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db.update(orders).set({ status: status as any }).where(eq(orders.id, orderId));
}

export async function getPortraitCustomization(orderId: number) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  const result = await db
    .select()
    .from(portraitCustomizations)
    .where(eq(portraitCustomizations.orderId, orderId))
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function updatePortraitPreview(orderId: number, previewUrl: string) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  await db
    .update(portraitCustomizations)
    .set({ previewUrl })
    .where(eq(portraitCustomizations.orderId, orderId));
}
