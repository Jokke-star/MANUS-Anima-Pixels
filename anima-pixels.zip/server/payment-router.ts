import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { createCheckoutSession, getCheckoutSession } from "./stripe-handler";

export const paymentRouter = router({
  // Create checkout session
  createCheckoutSession: publicProcedure
    .input(
      z.object({
        orderId: z.number(),
        orderNumber: z.string(),
        customerEmail: z.string().email(),
        customerName: z.string(),
        totalPrice: z.number().positive(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const origin = ctx.req.headers.origin || "https://anima-pixels.manus.space";

        const session = await createCheckoutSession({
          orderId: input.orderId,
          orderNumber: input.orderNumber,
          customerEmail: input.customerEmail,
          customerName: input.customerName,
          totalPrice: input.totalPrice,
          origin,
        });

        return {
          success: true,
          sessionId: session.id,
          url: session.url,
        };
      } catch (error) {
        console.error("[Payment] Checkout session creation failed:", error);
        throw error;
      }
    }),

  // Get checkout session details
  getCheckoutSession: publicProcedure
    .input(z.object({ sessionId: z.string() }))
    .query(async ({ input }) => {
      try {
        const session = await getCheckoutSession(input.sessionId);
        return {
          success: true,
          status: session.payment_status,
          paymentStatus: session.payment_status,
          customerEmail: session.customer_email,
          amountTotal: session.amount_total,
        };
      } catch (error) {
        console.error("[Payment] Get session failed:", error);
        throw error;
      }
    }),
});
