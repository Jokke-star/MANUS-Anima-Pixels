import Stripe from "stripe";
import { ENV } from "./_core/env";
import { updateOrderStatus } from "./orders";
import { getOrderById } from "./orders";

const stripe = new Stripe(ENV.stripeSecretKey);

export async function createCheckoutSession(data: {
  orderId: number;
  orderNumber: string;
  customerEmail: string;
  customerName: string;
  totalPrice: number;
  origin: string;
}) {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      mode: "payment",
      customer_email: data.customerEmail,
      client_reference_id: data.orderId.toString(),
      metadata: {
        order_id: data.orderId.toString(),
        order_number: data.orderNumber,
        customer_email: data.customerEmail,
        customer_name: data.customerName,
      },
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: `Custom Pet Portrait - Order ${data.orderNumber}`,
              description: "Premium custom pet portrait with framing and shipping",
              images: ["https://images.unsplash.com/photo-1558788353-f76d92427f16?w=500"],
            },
            unit_amount: data.totalPrice,
          },
          quantity: 1,
        },
      ],
      success_url: `${data.origin}/order-confirmation?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${data.origin}/order?cancelled=true`,
      allow_promotion_codes: true,
    });

    return session;
  } catch (error) {
    console.error("[Stripe] Checkout session creation failed:", error);
    throw error;
  }
}

export async function handlePaymentIntentSucceeded(event: Stripe.Event) {
  const paymentIntent = event.data.object as Stripe.PaymentIntent;

  try {
    const clientReferenceId = (paymentIntent as any).client_reference_id;
    if (!clientReferenceId) {
      console.warn("[Stripe] Payment intent missing client_reference_id");
      return;
    }

    const orderId = parseInt(clientReferenceId, 10);
    if (isNaN(orderId)) {
      console.warn("[Stripe] Invalid order ID in payment intent");
      return;
    }

    // Update order status to processing
    await updateOrderStatus(orderId, "processing");

    console.log(`[Stripe] Payment succeeded for order ${orderId}`);
  } catch (error) {
    console.error("[Stripe] Payment intent handler failed:", error);
    throw error;
  }
}

export async function handleCheckoutSessionCompleted(event: Stripe.Event) {
  const session = event.data.object as Stripe.Checkout.Session;

  try {
    const clientReferenceId = session.client_reference_id;
    if (!clientReferenceId) {
      console.warn("[Stripe] Checkout session missing client_reference_id");
      return;
    }

    const orderId = parseInt(clientReferenceId, 10);
    if (isNaN(orderId)) {
      console.warn("[Stripe] Invalid order ID in checkout session");
      return;
    }

    // Update order with payment intent ID
    const order = await getOrderById(orderId);
    if (order) {
      // Store payment intent ID for reference
      console.log(
        `[Stripe] Checkout completed for order ${orderId}, session: ${session.id}`
      );
    }
  } catch (error) {
    console.error("[Stripe] Checkout session handler failed:", error);
    throw error;
  }
}

export async function constructWebhookEvent(body: Buffer, signature: string) {
  try {
    const event = stripe.webhooks.constructEvent(
      body,
      signature,
      ENV.stripeWebhookSecret
    );
    return event;
  } catch (error) {
    console.error("[Stripe] Webhook signature verification failed:", error);
    throw error;
  }
}

export async function getCheckoutSession(sessionId: string) {
  try {
    const session = await stripe.checkout.sessions.retrieve(sessionId);
    return session;
  } catch (error) {
    console.error("[Stripe] Failed to retrieve checkout session:", error);
    throw error;
  }
}
