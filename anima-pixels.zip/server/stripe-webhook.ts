import { Router } from "express";
import { handleCheckoutSessionCompleted, handlePaymentIntentSucceeded, constructWebhookEvent } from "./stripe-handler";

const router = Router();

router.post("/stripe/webhook", async (req, res) => {
  const signature = req.headers["stripe-signature"] as string;

  if (!signature) {
    console.warn("[Webhook] Missing stripe-signature header");
    return res.status(400).json({ error: "Missing signature" });
  }

  try {
    const event = await constructWebhookEvent(req.body as Buffer, signature);

    // Handle test events
    if (event.id.startsWith("evt_test_")) {
      console.log("[Webhook] Test event detected, returning verification response");
      return res.json({
        verified: true,
      });
    }

    // Handle different event types
    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutSessionCompleted(event);
        break;

      case "payment_intent.succeeded":
        await handlePaymentIntentSucceeded(event);
        break;

      case "payment_intent.payment_failed":
        console.log("[Webhook] Payment failed:", (event.data.object as any));
        break;

      default:
        console.log(`[Webhook] Unhandled event type: ${event.type}`);
    }

    res.json({ received: true });
  } catch (error) {
    console.error("[Webhook] Error processing webhook:", error);
    res.status(400).json({ error: "Webhook error" });
  }
});

export default router;
