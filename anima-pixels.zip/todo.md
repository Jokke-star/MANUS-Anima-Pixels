# Anima Pixels - Project TODO

## Landing Page & Marketing
- [x] Hero section with emotional headline and CTA
- [x] Portrait gallery with art style showcase
- [x] Emotional marketing sections with colorful blocks
- [x] How it works step-by-step flow
- [x] Testimonials section
- [x] Final CTA section
- [x] Footer with navigation and social links

## Order Wizard & Customization
- [x] Multi-step order wizard with progress indicator
- [x] Photo upload with preview functionality
- [x] Portrait style selection (Watercolor, Oil, Digital, Sketch, etc.)
- [x] Frame options (Wood, Black, White)
- [x] Size selection (8x10, 12x12, 12x16, 18x24)
- [x] Special instructions text area
- [x] Order summary page

## Customer Information & Checkout
- [x] Customer information form (Name, Email, Address)
- [x] Stripe payment integration
- [x] Secure checkout flow
- [x] Order confirmation page

## Backend Features
- [x] Database schema for orders, customers, and portraits
- [x] Order creation and management procedures
- [x] Photo upload to S3 storage
- [x] Email notification system for new orders
- [x] Order status tracking

## AI & Preview Features
- [x] AI-powered preview generation for different art styles
- [x] Preview image generation before checkout
- [x] Caching of preview images

## Design & UX
- [x] Responsive design for mobile and desktop
- [x] Luxury color palette (teal, coral, lavender, gold)
- [x] Smooth animations and hover effects
- [x] Premium typography and spacing
- [x] Rounded cards with soft shadows

## Testing & Deployment
- [x] Unit tests for backend procedures
- [x] Integration tests for order flow
- [x] Responsive design testing
- [x] Payment flow testing

## Logo & Branding Updates
- [x] Replace AP logo in navbar with Anima Pixels logo
- [x] Replace heart icon in hero section with Anima Pixels logo
- [x] Increase logo sizes 3x from original
- [x] Double logo sizes 2x from previous size
- [x] Replace yellow paws image with dog photo in "Gift for Your Most Loyal Friend" section
- [x] Create slideshow carousel with 2-second transitions
- [x] Add dot indicators for manual slide navigation
- [x] Add third dog image (black and white portrait) to slideshow
- [x] Reduce header/navbar height and logo size
- [x] Reduce hero section spacing and logo size
- [x] Enhance hero background with artistic gradients and inspiration
- [x] Double hero logo size from w-48 h-48 to w-96 h-96
- [x] Create modern paws pattern background
- [x] Generate paws background in teal, purple, and coral colors
- [x] Add paws background behind logo and text in hero section
